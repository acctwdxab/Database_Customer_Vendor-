var mysql = require("mysql2");
var pool = mysql.createConnection({
  connectionLimit: 10,
  host: "classmysql.engr.oregonstate.edu",
  user: "CS340_choyo",
  password: "8420",
  database: "CS340_choyo",
  dateStrings : true,
});

module.exports.connection = pool;
