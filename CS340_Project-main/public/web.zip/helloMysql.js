var express = require('express');
var mysql = require('./dbcon.js');

var app = express();
var handlebars = require('express-handlebars').create({defaultLayout:'main'});

app.use(express.static('public'))
app.engine('handlebars', handlebars.engine);
app.set('view engine', 'handlebars');

app.set('port', 48421);

app.get('/',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM workouts', function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);

    res.send(context);
  });
});

app.get('/get_one',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM workouts WHERE id=?',[req.query.id], function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);

    res.send(context);
  });
});

app.get('/insert',function(req,res,next){
  var context = {};
  mysql.pool.query("INSERT INTO workouts (`name`,`reps`,`weight`,`date`,`lbs` ) VALUES (?,?,?,?,?)", [req.query.name, req.query.reps,req.query.weight,req.query.date,req.query.lbs], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "ID:" + result.insertId;
    res.send(context.results);

  });
});

app.get('/delete',function(req,res,next){
  var context = {};
  mysql.pool.query("DELETE FROM workouts WHERE id=?", [req.query.id], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "Deleted " + result.changedRows + " rows.";
    res.send(context);
  });
});


///simple-update?id=2&name=The+Task&done=false&due=2015-12-5
app.get('/simple-update',function(req,res,next){
  var context = {};
  mysql.pool.query("UPDATE workouts SET name=?, reps=?, weight=?, date=?, lbs=?  WHERE id=? ",
    [req.query.name, req.query.reps, req.query.weight, req.query.date, req.query.lbs, req.query.id],
    function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "Updated " + result.changedRows + " rows.";
    res.send(context);
  });
});

app.get('/reset-table',function(req,res,next){
  var context = {};
  mysql.pool.query("DROP TABLE IF EXISTS workouts", function(err){ 
    var createString = "CREATE TABLE workouts("+
    "id INT PRIMARY KEY AUTO_INCREMENT,"+
    "name VARCHAR(255) NOT NULL,"+
    "reps INT NOT NULL,"+
    "weight INT NOT NULL,"+
    "date DATE NOT NULL,"+
    "lbs BOOLEAN NOT NULL)";
    mysql.pool.query(createString, function(err){
      context.results = "Table reset";
      res.send(context);
    })
  });
});



app.get('/customer',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM Customer', function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);

    res.send(context);
  });
});

app.get('/get_one_customer',function(req,res,next){
  var context = {};
  mysql.pool.query('SELECT * FROM Customer WHERE customerID=?',[req.query.customerID], function(err, rows, fields){
    if(err){
      next(err);
      return;
    }
    context.results = JSON.stringify(rows);

    res.send(context);
  });
});

app.get('/insert_customer',function(req,res,next){
  var context = {};
  mysql.pool.query("INSERT INTO Customer (`email`,`entityName`,`location`) VALUES (?,?,?)", [req.query.email, req.query.entityName, req.query.location], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "ID:" + result.insertId;
    res.send(context.results);

  });
});


app.get('/delete_customer',function(req,res,next){
  var context = {};
  mysql.pool.query("DELETE FROM Customer WHERE customerID=?", [req.query.customerID], function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "Deleted " + result.changedRows + " rows.";
    res.send(context);
  });
});

app.get('/update_customer',function(req,res,next){
  var context = {};
  mysql.pool.query("UPDATE Customer SET email=?, entityName=?, location=? WHERE customerID=? ",
    [req.query.email, req.query.entityName, req.query.location, req.query.customerID],
    function(err, result){
    if(err){
      next(err);
      return;
    }
    context.results = "Updated " + result.changedRows + " rows.";
    res.send(context);
  });
});

app.get('/reset_customer',function(req,res,next){
  var context = {};
  mysql.pool.query("DROP TABLE IF EXISTS Customer", function(err){ 
    var createString = "CREATE TABLE Customer("+
    "customerID INT PRIMARY KEY AUTO_INCREMENT,"+
    "email VARCHAR(255) NOT NULL,"+
	"entityName VARCHAR(255) NOT NULL,"+
	"location VARCHAR(45) NOT NULL)"	
    mysql.pool.query(createString, function(err){
      context.results = "Table reset";
      res.send(context);
    })
  });
});





app.use(function(req,res){
  res.status(404);
  res.send('404');
});

app.use(function(err, req, res, next){
  console.error(err.stack);
  res.status(500);
  res.send('500');
});

app.listen(app.get('port'), function(){
  console.log('Express started on http://localhost:' + app.get('port') + '; press Ctrl-C to terminate.');
});
